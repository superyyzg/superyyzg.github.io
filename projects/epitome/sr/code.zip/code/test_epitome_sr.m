%episr_para.epitome_weight = 0.5;
%episr_para.magFac = 2;

%coarse setting
% episr_para.ps_scale = 1;
% episr_para.patchPeriod = [1/2 1/2];
% episr_para.eSizeRatio = [1/10 1/10];
% episr_para.splitRatio = 6;
% episr_para.kNN = 200;
% 
% sr_para.nStep = 8;
% sr_para.hps = 12;
% sr_para.hss = 6;


episr_para.epitome_weight = 0.5;
episr_para.magFac = 3;

%fine setting
episr_para.ps_scale = 1;
episr_para.patchPeriod = [1/5 1/5];
episr_para.eSizeRatio = [1/4 1/4];
episr_para.splitRatio = 1;
episr_para.kNN = 50;

sr_para.nStep = 1;
sr_para.hps = 2;
sr_para.hss = 5;

targetsize = [320 480];

save('epitome_sr_para','episr_para','sr_para','targetsize');

systemline = ['epitome_sr.exe ', '1.png'];
system(systemline)



